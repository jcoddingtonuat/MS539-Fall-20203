﻿namespace MS539_1_17_24_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.UATPopbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.intToCheckTB = new System.Windows.Forms.TextBox();
            this.checkIntbtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.RollDicebtn = new System.Windows.Forms.Button();
            this.GotoUATLL = new System.Windows.Forms.LinkLabel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.DBCB = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.GUICB = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ClassGB = new System.Windows.Forms.GroupBox();
            this.FreshmanRB = new System.Windows.Forms.RadioButton();
            this.sophmoreRB = new System.Windows.Forms.RadioButton();
            this.JuniorRB = new System.Windows.Forms.RadioButton();
            this.SeniorRB = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.ClassGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // UATPopbtn
            // 
            this.UATPopbtn.Font = new System.Drawing.Font("MingLiU-ExtB", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UATPopbtn.Location = new System.Drawing.Point(151, 100);
            this.UATPopbtn.Name = "UATPopbtn";
            this.UATPopbtn.Size = new System.Drawing.Size(319, 160);
            this.UATPopbtn.TabIndex = 0;
            this.UATPopbtn.Text = "Make things happen";
            this.toolTip1.SetToolTip(this.UATPopbtn, "This will display a popup");
            this.UATPopbtn.UseVisualStyleBackColor = true;
            this.UATPopbtn.Click += new System.EventHandler(this.UATPopbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(62, 349);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter an integer";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // intToCheckTB
            // 
            this.intToCheckTB.Location = new System.Drawing.Point(356, 349);
            this.intToCheckTB.Name = "intToCheckTB";
            this.intToCheckTB.Size = new System.Drawing.Size(349, 38);
            this.intToCheckTB.TabIndex = 2;
            // 
            // checkIntbtn
            // 
            this.checkIntbtn.Location = new System.Drawing.Point(711, 317);
            this.checkIntbtn.Name = "checkIntbtn";
            this.checkIntbtn.Size = new System.Drawing.Size(223, 95);
            this.checkIntbtn.TabIndex = 3;
            this.checkIntbtn.Text = "Check integer";
            this.checkIntbtn.UseVisualStyleBackColor = true;
            this.checkIntbtn.Click += new System.EventHandler(this.checkIntbtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(117, 498);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(412, 328);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // RollDicebtn
            // 
            this.RollDicebtn.Location = new System.Drawing.Point(204, 393);
            this.RollDicebtn.Name = "RollDicebtn";
            this.RollDicebtn.Size = new System.Drawing.Size(178, 99);
            this.RollDicebtn.TabIndex = 5;
            this.RollDicebtn.Text = "Roll the Dice";
            this.RollDicebtn.UseVisualStyleBackColor = true;
            this.RollDicebtn.Click += new System.EventHandler(this.RollDicebtn_Click);
            // 
            // GotoUATLL
            // 
            this.GotoUATLL.AutoSize = true;
            this.GotoUATLL.Location = new System.Drawing.Point(881, 130);
            this.GotoUATLL.Name = "GotoUATLL";
            this.GotoUATLL.Size = new System.Drawing.Size(240, 32);
            this.GotoUATLL.TabIndex = 6;
            this.GotoUATLL.TabStop = true;
            this.GotoUATLL.Text = "Click to go to UAT";
            this.GotoUATLL.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.GotoUATLL_LinkClicked);
            // 
            // DBCB
            // 
            this.DBCB.AutoSize = true;
            this.DBCB.Location = new System.Drawing.Point(1171, 254);
            this.DBCB.Name = "DBCB";
            this.DBCB.Size = new System.Drawing.Size(174, 36);
            this.DBCB.TabIndex = 7;
            this.DBCB.Text = "Database";
            this.DBCB.UseVisualStyleBackColor = true;
            this.DBCB.CheckedChanged += new System.EventHandler(this.DBCB_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1191, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(347, 32);
            this.label2.TabIndex = 8;
            this.label2.Text = "Skills - check all that apply";
            // 
            // GUICB
            // 
            this.GUICB.AutoSize = true;
            this.GUICB.Location = new System.Drawing.Point(1171, 317);
            this.GUICB.Name = "GUICB";
            this.GUICB.Size = new System.Drawing.Size(229, 36);
            this.GUICB.TabIndex = 9;
            this.GUICB.Text = "Front End dev";
            this.GUICB.UseVisualStyleBackColor = true;
            this.GUICB.CheckedChanged += new System.EventHandler(this.GUICB_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1137, 520);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(187, 32);
            this.label3.TabIndex = 10;
            this.label3.Text = "Current class ";
            // 
            // ClassGB
            // 
            this.ClassGB.Controls.Add(this.SeniorRB);
            this.ClassGB.Controls.Add(this.JuniorRB);
            this.ClassGB.Controls.Add(this.sophmoreRB);
            this.ClassGB.Controls.Add(this.FreshmanRB);
            this.ClassGB.Location = new System.Drawing.Point(1143, 622);
            this.ClassGB.Name = "ClassGB";
            this.ClassGB.Size = new System.Drawing.Size(357, 252);
            this.ClassGB.TabIndex = 11;
            this.ClassGB.TabStop = false;
            // 
            // FreshmanRB
            // 
            this.FreshmanRB.AutoSize = true;
            this.FreshmanRB.Location = new System.Drawing.Point(28, 23);
            this.FreshmanRB.Name = "FreshmanRB";
            this.FreshmanRB.Size = new System.Drawing.Size(169, 36);
            this.FreshmanRB.TabIndex = 0;
            this.FreshmanRB.TabStop = true;
            this.FreshmanRB.Text = "freshman";
            this.FreshmanRB.UseVisualStyleBackColor = true;
            this.FreshmanRB.CheckedChanged += new System.EventHandler(this.FreshmanRB_CheckedChanged);
            // 
            // sophmoreRB
            // 
            this.sophmoreRB.AutoSize = true;
            this.sophmoreRB.Location = new System.Drawing.Point(28, 66);
            this.sophmoreRB.Name = "sophmoreRB";
            this.sophmoreRB.Size = new System.Drawing.Size(177, 36);
            this.sophmoreRB.TabIndex = 1;
            this.sophmoreRB.TabStop = true;
            this.sophmoreRB.Text = "sophmore";
            this.sophmoreRB.UseVisualStyleBackColor = true;
            // 
            // JuniorRB
            // 
            this.JuniorRB.AutoSize = true;
            this.JuniorRB.Location = new System.Drawing.Point(28, 109);
            this.JuniorRB.Name = "JuniorRB";
            this.JuniorRB.Size = new System.Drawing.Size(129, 36);
            this.JuniorRB.TabIndex = 2;
            this.JuniorRB.TabStop = true;
            this.JuniorRB.Text = "Junior";
            this.JuniorRB.UseVisualStyleBackColor = true;
            // 
            // SeniorRB
            // 
            this.SeniorRB.AutoSize = true;
            this.SeniorRB.Location = new System.Drawing.Point(28, 167);
            this.SeniorRB.Name = "SeniorRB";
            this.SeniorRB.Size = new System.Drawing.Size(129, 36);
            this.SeniorRB.TabIndex = 3;
            this.SeniorRB.TabStop = true;
            this.SeniorRB.Text = "senior";
            this.SeniorRB.UseVisualStyleBackColor = true;
            this.SeniorRB.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1749, 1117);
            this.Controls.Add(this.ClassGB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.GUICB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DBCB);
            this.Controls.Add(this.GotoUATLL);
            this.Controls.Add(this.RollDicebtn);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.checkIntbtn);
            this.Controls.Add(this.intToCheckTB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.UATPopbtn);
            this.Name = "Form1";
            this.Text = "First GUI";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ClassGB.ResumeLayout(false);
            this.ClassGB.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button UATPopbtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox intToCheckTB;
        private System.Windows.Forms.Button checkIntbtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button RollDicebtn;
        private System.Windows.Forms.LinkLabel GotoUATLL;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.CheckBox DBCB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox GUICB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox ClassGB;
        private System.Windows.Forms.RadioButton JuniorRB;
        private System.Windows.Forms.RadioButton sophmoreRB;
        private System.Windows.Forms.RadioButton FreshmanRB;
        private System.Windows.Forms.RadioButton SeniorRB;
    }
}

