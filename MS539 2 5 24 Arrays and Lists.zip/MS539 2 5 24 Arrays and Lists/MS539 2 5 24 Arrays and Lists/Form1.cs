﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MS539_2_5_24_Arrays_and_Lists
{
    public partial class Form1 : Form
    {

        String[] texts = new string[3];
        double[] numbers = new double[4];
      
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ConcatBTN_Click(object sender, EventArgs e)
        {
            texts[0] = textBox1.Text;
            texts[1] = textBox2.Text;
            texts[2] = textBox3.Text;

            string Longtext = "";

            for (int i = 0; i < texts.Length; i++) 
            {
                Longtext += texts[i];// Longtext = longtext + texts[i]
            }
            textBox4.Text = Longtext;
  


        }

        private void AddDoubleBTN_Click(object sender, EventArgs e)
        {
            numbers[3] = 42;
            double sum = 0;
            numbers[0] = int.Parse(Double1TB.Text);
            numbers[1] = int.Parse(double2TB.Text);
            numbers[2] = int.Parse(Double3TB.Text);
            // assumes all numbers - no exception handling (don't do this)
            for (int i = 0; i< numbers.Length; i++)
            {
                    sum += numbers[i];
            }
            doubleSumTB.Text = sum.ToString();

        }

        private void SortdoubleBTN_Click(object sender, EventArgs e)
        {
            string sorted = "";
            Array.Sort(numbers);
            //foreach (int i in numbers) { }
            for (int i = 0; i < numbers.Length; i++) 
            {
                sorted += numbers[i].ToString();

            }
            SortDoubleTB.Text = sorted;
        }

    
    }
}
