﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ms539_9_27_23_functions
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // functions go here
        void display()
        {
            MessageBox.Show("inside function");
            textBox1.Text = "Im in a function";

        }
        double avg(int num1, int num2, int num3)
        {
            return Convert.ToDouble((num1 + num2 + num3) / 3.0);
        }

        int sum(int a, int b, int c)
        {
            int total = a + b;
            return total;
            // return (a+b+c);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            display();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double av = avg(1, 2, 1);
            textBox1.Text = av.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int addition = sum(1, 2, 3);
            MessageBox.Show("sum = " + addition);

        }
    }
}
