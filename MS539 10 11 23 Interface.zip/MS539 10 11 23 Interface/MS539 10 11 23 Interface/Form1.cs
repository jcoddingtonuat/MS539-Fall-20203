﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MS539_10_11_23_Interface
{
    public partial class Form1 : Form
    {
        interface IDrawing
        {
            void render();
        }

        class tablet : IDrawing
        {
            public void render()
            {
                MessageBox.Show("render on a tablet");
            }
        }

        class android :IDrawing
        {

            public void render()
            {
                MessageBox.Show("render on an android");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            tablet myTablet = new tablet();
            myTablet.render();

            android myAndroid = new android();
            myAndroid.render(); 

        }
    }
}
