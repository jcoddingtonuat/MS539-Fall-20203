﻿namespace MS539_2_5_24_Arrays_and_Lists
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.ConcatBTN = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Double1TB = new System.Windows.Forms.TextBox();
            this.double2TB = new System.Windows.Forms.TextBox();
            this.Double3TB = new System.Windows.Forms.TextBox();
            this.AddDoubleBTN = new System.Windows.Forms.Button();
            this.doubleSumTB = new System.Windows.Forms.TextBox();
            this.SortdoubleBTN = new System.Windows.Forms.Button();
            this.SortDoubleTB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(115, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "string 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(121, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "string2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(127, 209);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "string 3";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(402, 42);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 38);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(402, 137);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 38);
            this.textBox2.TabIndex = 4;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(402, 202);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 38);
            this.textBox3.TabIndex = 5;
            // 
            // ConcatBTN
            // 
            this.ConcatBTN.Location = new System.Drawing.Point(723, 42);
            this.ConcatBTN.Name = "ConcatBTN";
            this.ConcatBTN.Size = new System.Drawing.Size(241, 121);
            this.ConcatBTN.TabIndex = 6;
            this.ConcatBTN.Text = "Concatenate";
            this.ConcatBTN.UseVisualStyleBackColor = true;
            this.ConcatBTN.Click += new System.EventHandler(this.ConcatBTN_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(1061, 61);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(578, 38);
            this.textBox4.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(121, 375);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 32);
            this.label4.TabIndex = 8;
            this.label4.Text = "Double 1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(127, 462);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 32);
            this.label5.TabIndex = 9;
            this.label5.Text = "double 2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(121, 571);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 32);
            this.label6.TabIndex = 10;
            this.label6.Text = "double 3";
            // 
            // Double1TB
            // 
            this.Double1TB.Location = new System.Drawing.Point(391, 368);
            this.Double1TB.Name = "Double1TB";
            this.Double1TB.Size = new System.Drawing.Size(100, 38);
            this.Double1TB.TabIndex = 11;
            // 
            // double2TB
            // 
            this.double2TB.Location = new System.Drawing.Point(391, 455);
            this.double2TB.Name = "double2TB";
            this.double2TB.Size = new System.Drawing.Size(100, 38);
            this.double2TB.TabIndex = 12;
            // 
            // Double3TB
            // 
            this.Double3TB.Location = new System.Drawing.Point(391, 571);
            this.Double3TB.Name = "Double3TB";
            this.Double3TB.Size = new System.Drawing.Size(100, 38);
            this.Double3TB.TabIndex = 13;
            // 
            // AddDoubleBTN
            // 
            this.AddDoubleBTN.Location = new System.Drawing.Point(741, 383);
            this.AddDoubleBTN.Name = "AddDoubleBTN";
            this.AddDoubleBTN.Size = new System.Drawing.Size(173, 111);
            this.AddDoubleBTN.TabIndex = 14;
            this.AddDoubleBTN.Text = "Add doubles";
            this.AddDoubleBTN.UseVisualStyleBackColor = true;
            this.AddDoubleBTN.Click += new System.EventHandler(this.AddDoubleBTN_Click);
            // 
            // doubleSumTB
            // 
            this.doubleSumTB.Location = new System.Drawing.Point(1121, 383);
            this.doubleSumTB.Name = "doubleSumTB";
            this.doubleSumTB.Size = new System.Drawing.Size(100, 38);
            this.doubleSumTB.TabIndex = 15;
            // 
            // SortdoubleBTN
            // 
            this.SortdoubleBTN.Location = new System.Drawing.Point(741, 526);
            this.SortdoubleBTN.Name = "SortdoubleBTN";
            this.SortdoubleBTN.Size = new System.Drawing.Size(173, 105);
            this.SortdoubleBTN.TabIndex = 16;
            this.SortdoubleBTN.Text = "Sort doubes";
            this.SortdoubleBTN.UseVisualStyleBackColor = true;
            this.SortdoubleBTN.Click += new System.EventHandler(this.SortdoubleBTN_Click);
            // 
            // SortDoubleTB
            // 
            this.SortDoubleTB.Location = new System.Drawing.Point(1121, 538);
            this.SortDoubleTB.Name = "SortDoubleTB";
            this.SortDoubleTB.Size = new System.Drawing.Size(100, 38);
            this.SortDoubleTB.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1734, 989);
            this.Controls.Add(this.SortDoubleTB);
            this.Controls.Add(this.SortdoubleBTN);
            this.Controls.Add(this.doubleSumTB);
            this.Controls.Add(this.AddDoubleBTN);
            this.Controls.Add(this.Double3TB);
            this.Controls.Add(this.double2TB);
            this.Controls.Add(this.Double1TB);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.ConcatBTN);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button ConcatBTN;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Double1TB;
        private System.Windows.Forms.TextBox double2TB;
        private System.Windows.Forms.TextBox Double3TB;
        private System.Windows.Forms.Button AddDoubleBTN;
        private System.Windows.Forms.TextBox doubleSumTB;
        private System.Windows.Forms.Button SortdoubleBTN;
        private System.Windows.Forms.TextBox SortDoubleTB;
    }
}

