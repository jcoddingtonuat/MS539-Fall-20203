﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MS539_1_17_24_GUI
{
    public partial class Form1 : Form
    {// this is where variable for this form are declared
        int num1, die;
        public Form1()
        {
            InitializeComponent();
        }

        private void UATPopbtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("UAT rocks!");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkIntbtn_Click(object sender, EventArgs e)
        {
            if (int.TryParse(intToCheckTB.Text, out num1))
            {
                MessageBox.Show("This is valid - the number is " + num1);
            }
            else
            {
                MessageBox.Show("This is NOT a valid integer");
            }
        }

        private void GotoUATLL_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try 
            {
                GotoUATLL.LinkVisited = true;
                System.Diagnostics.Process.Start("http://www.uat.edu");
            }
            catch
            {
                MessageBox.Show("Could not get to UAT website");
            }

        }

        private void DBCB_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void GUICB_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void FreshmanRB_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RollDicebtn_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            die = rnd.Next(1, 6);

            switch(die)
            { case 1:
                  
                    {
                        pictureBox1.ImageLocation = "C:/Users/Jill/UAT/Grad Development/MSE539/dice1.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;

                    }
                    break;
            case 2:
                    {
                        {
                            pictureBox1.ImageLocation = "C:/Users/Jill/UAT/Grad Development/MSE539/dice2.png";
                            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                        }
                    }
                    break;
                case 3:
                    {
                        {
                            pictureBox1.ImageLocation = "C:/Users/Jill/UAT/Grad Development/MSE539/dice3.png";
                            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                        }
                    }
                    break;
                case 4:
                    {
                        {
                            pictureBox1.ImageLocation = "C:/Users/Jill/UAT/Grad Development/MSE539/dice4.png";
                            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                        }
                    }
                    break;
                case 5:
                    {
                        {
                            pictureBox1.ImageLocation = "C:/Users/Jill/UAT/Grad Development/MSE539/dice5.png";
                            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                        }
                    }
                    break;
                case 6:
                    {
                        {
                            pictureBox1.ImageLocation = "C:/Users/Jill/UAT/Grad Development/MSE539/dice6.png";
                            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                        }
                    }
                    break;
                default:
                     MessageBox.Show("error - not 1-6 ");
                    break;
            }
            /*    if (die == 1)
                {
                    pictureBox1.ImageLocation = "C:/Users/Jill/UAT/Grad Development/MSE539/dice1.png"; 
                    pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;

                }
                else if (die == 2)
                {
                    pictureBox1.ImageLocation = "C:/Users/Jill/UAT/Grad Development/MSE539/dice2.png";
                    pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                }
                else if (die == 3)
                {
                    pictureBox1.ImageLocation = "C:/Users/Jill/UAT/Grad Development/MSE539/dice3.png";
                    pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                }
                else if (die == 4)
                {
                    pictureBox1.ImageLocation = "C:/Users/Jill/UAT/Grad Development/MSE539/dice4.png";
                    pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                }
                else if (die == 5)
                {
                    pictureBox1.ImageLocation = "C:/Users/Jill/UAT/Grad Development/MSE539/dice5.png";
                    pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                }
                else if (die == 6)
                {
                    pictureBox1.ImageLocation = "C:/Users/Jill/UAT/Grad Development/MSE539/dice6.png";
                    pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                }
                else
                { MessageBox.Show("error - not 1-6 "); }
              */
        }
 


    }
}
